import './heroContent.css';

export default function HeroContent() {
    return(
        <div className="content banner">
            <h2>Your 547Adventure Awaits</h2>
            <div>Discover and book the best dirt-bike parks and motocross tracks near you.</div>
        </div>
    )
}